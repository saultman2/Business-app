import { useState, useMemo, useEffect } from "react";
import { useLocation } from "wouter";
import {
  useListClients,
  useListJobs,
  useGetCompany,
  useCreateClient,
  useCreateJob,
  useCreateEstimate,
  useCreateEstimateItem,
  useUpdateEstimate,
  useAiQuickQuote,
  useAiMaterialPrice,
} from "@workspace/api-client-react";
import type { AiMaterialPriceResult } from "@workspace/api-client-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import {
  Sparkles,
  Plus,
  X,
  Printer,
  Save,
  Loader2,
  ArrowLeft,
  ArrowRight,
  Check,
  Tag,
  AlertTriangle,
  UserRound,
  ChevronRight,
} from "lucide-react";
import { formatCurrency } from "@/lib/format";

type Step = "client" | "describe" | "review" | "preview";
type Section = "material" | "labor";

interface LineItem {
  id: string;
  section: Section;
  description: string;
  qty: number;
  unit: string;
  unitPrice: number;
}

const JOB_TYPES = [
  "General Construction",
  "Remodeling",
  "Roofing",
  "Electrical",
  "Plumbing",
  "HVAC",
  "Painting",
  "Flooring",
  "Concrete / Masonry",
  "Landscaping",
  "Carpentry",
  "Drywall",
  "Fencing",
  "Gutters",
  "Other",
];

const DESCRIPTION_TEMPLATE = `Tell me what job you are quoting. Include the type of work, measurements, materials wanted, location details, condition of the existing area, timeline, and anything special the customer asked for.

Example:
Customer wants 120 feet of 6-inch seamless gutters installed on a single-story house. Existing gutters need to be removed. Include downspouts, hangers, end caps, corners, labor, disposal, and cleanup.`;

let idCounter = 0;
const nextId = () => `li-${idCounter++}`;

function emptyItem(section: Section): LineItem {
  return {
    id: nextId(),
    section,
    description: "",
    qty: 1,
    unit: section === "labor" ? "hr" : "ea",
    unitPrice: 0,
  };
}

const STEPS: Step[] = ["client", "describe", "review", "preview"];
const STEP_LABELS: Record<Step, string> = {
  client: "Client",
  describe: "Job Description",
  review: "Review Quote",
  preview: "Save & Send",
};

export default function QuickQuotePage() {
  const [, setLocation] = useLocation();
  const { toast } = useToast();

  const { data: clients } = useListClients({});
  const { data: jobs } = useListJobs({});
  const { data: company } = useGetCompany();

  const createClient = useCreateClient();
  const createJob = useCreateJob();
  const createEstimate = useCreateEstimate();
  const createItem = useCreateEstimateItem();
  const updateEstimate = useUpdateEstimate();
  const aiQuickQuote = useAiQuickQuote();
  const materialPrice = useAiMaterialPrice();

  const [step, setStep] = useState<Step>("client");

  // Client
  const [clientNameInput, setClientNameInput] = useState("");
  const [clientId, setClientId] = useState<number | null>(null);
  const [clientMode, setClientMode] = useState<"new" | "existing" | null>(null);

  // Job
  const [jobId, setJobId] = useState<number | null>(null);
  const [jobType, setJobType] = useState("General Construction");
  const [description, setDescription] = useState("");
  const [showTemplate, setShowTemplate] = useState(false);

  // AI
  const [aiGenerated, setAiGenerated] = useState(false);

  // Line items + tax
  const [items, setItems] = useState<LineItem[]>([]);
  const [taxRate, setTaxRate] = useState<number>(0);

  // Price hints keyed by line item id
  const [hints, setHints] = useState<Record<string, AiMaterialPriceResult | null>>({});
  const [hintLoading, setHintLoading] = useState<Record<string, boolean>>({});

  const [isSaving, setIsSaving] = useState(false);
  const [newJobTitle, setNewJobTitle] = useState("");

  // Sync tax rate from company settings
  useEffect(() => {
    if (company?.defaultTaxRate != null) setTaxRate(company.defaultTaxRate);
  }, [company?.defaultTaxRate]);

  const selectedClient = clients?.find((c) => c.id === clientId) || null;
  const selectedJob = jobs?.find((j) => j.id === jobId) || null;

  // Filter clients by what the user typed
  const matchingClients = useMemo(() => {
    const q = clientNameInput.trim().toLowerCase();
    if (!q || !clients) return [];
    return clients.filter((c) => c.name.toLowerCase().includes(q)).slice(0, 5);
  }, [clientNameInput, clients]);

  const exactMatch = useMemo(() => {
    const q = clientNameInput.trim().toLowerCase();
    return clients?.find((c) => c.name.toLowerCase() === q) || null;
  }, [clientNameInput, clients]);

  const subtotal = useMemo(
    () => items.reduce((s, i) => s + i.qty * i.unitPrice, 0),
    [items],
  );
  const taxAmount = subtotal * (taxRate / 100);
  const grandTotal = subtotal + taxAmount;

  const materialItems = items.filter((i) => i.section === "material");
  const laborItems = items.filter((i) => i.section === "labor");

  function updateItem(id: string, patch: Partial<LineItem>) {
    setItems((prev) => prev.map((i) => (i.id === id ? { ...i, ...patch } : i)));
  }

  function removeItem(id: string) {
    setItems((prev) => prev.filter((i) => i.id !== id));
    setHints((prev) => {
      const next = { ...prev };
      delete next[id];
      return next;
    });
  }

  function selectExistingClient(id: number) {
    setClientId(id);
    const c = clients?.find((x) => x.id === id);
    if (c) setClientNameInput(c.name);
    setClientMode("existing");
  }

  function proceedWithNewClient() {
    setClientId(null);
    setClientMode("new");
    setStep("describe");
  }

  function proceedWithExistingClient(id: number) {
    setClientId(id);
    const c = clients?.find((x) => x.id === id);
    if (c) setClientNameInput(c.name);
    setClientMode("existing");
    setStep("describe");
  }

  async function handleGenerateAi() {
    if (!description.trim()) {
      toast({ title: "Please describe the job first", variant: "destructive" });
      return;
    }
    try {
      const res = await aiQuickQuote.mutateAsync({
        data: {
          jobDescription: description.trim(),
          jobType: jobType || undefined,
          zipCode: company?.zipCode || undefined,
        },
      });
      const mats: LineItem[] = (res.materials || []).map((m) => ({
        id: nextId(),
        section: "material",
        description: m.name,
        qty: m.qty ?? 1,
        unit: m.unit ?? "ea",
        unitPrice: m.unitPrice ?? 0,
      }));
      const labor: LineItem[] = (res.labor || []).map((l) => ({
        id: nextId(),
        section: "labor",
        description: l.description,
        qty: l.qty ?? 1,
        unit: "hr",
        unitPrice: l.unitPrice ?? 0,
      }));
      setItems([...mats, ...labor]);
      setAiGenerated(true);
      setStep("review");
      toast({ title: "Quote drafted!", description: "Review and adjust the line items below." });
    } catch (err: unknown) {
      toast({
        title: "AI error",
        description: err instanceof Error ? err.message : "Failed to generate quote",
        variant: "destructive",
      });
    }
  }

  async function handleCheckPrice(item: LineItem) {
    if (!item.description.trim()) {
      toast({ title: "Enter an item name first", variant: "destructive" });
      return;
    }
    setHintLoading((p) => ({ ...p, [item.id]: true }));
    try {
      const res = await materialPrice.mutateAsync({
        data: { itemName: item.description.trim(), unit: item.unit || undefined },
      });
      setHints((p) => ({ ...p, [item.id]: res }));
    } catch {
      toast({ title: "Price lookup failed", variant: "destructive" });
    } finally {
      setHintLoading((p) => ({ ...p, [item.id]: false }));
    }
  }

  async function handleSave() {
    const validItems = items.filter((i) => i.description.trim());
    if (validItems.length === 0) {
      toast({ title: "Add at least one line item", variant: "destructive" });
      return;
    }

    setIsSaving(true);
    try {
      // 1. Resolve / create client
      let finalClientId = clientId;
      if (finalClientId == null && clientNameInput.trim()) {
        const c = await createClient.mutateAsync({ data: { name: clientNameInput.trim() } });
        finalClientId = c.id;
      }
      const clientName = selectedClient?.name || clientNameInput.trim();

      // 2. Create job
      let finalJobId = jobId;
      if (!finalJobId) {
        const title = newJobTitle.trim() || (clientName ? `${jobType} — ${clientName}` : jobType);
        const job = await createJob.mutateAsync({
          data: {
            title,
            jobType,
            clientId: finalClientId ?? undefined,
            description: description || undefined,
          },
        });
        finalJobId = job.id;
      }

      // 3. Create estimate
      const estTitle = selectedJob?.title || newJobTitle.trim() || `${jobType} Quote`;
      const est = await createEstimate.mutateAsync({
        data: {
          title: estTitle,
          jobId: finalJobId ?? undefined,
          clientId: finalClientId ?? undefined,
        },
      });

      // 4. Create line items
      let sortOrder = 0;
      for (const item of validItems) {
        await createItem.mutateAsync({
          estimateId: est.id,
          data: {
            section: item.section,
            description: item.description,
            quantity: item.section === "material" ? item.qty : undefined,
            unit: item.section === "material" ? item.unit : undefined,
            unitPrice: item.section === "material" ? item.unitPrice : undefined,
            hours: item.section === "labor" ? item.qty : undefined,
            hourlyRate: item.section === "labor" ? item.unitPrice : undefined,
            sortOrder: sortOrder++,
          },
        });
      }

      // 5. Configure totals
      await updateEstimate.mutateAsync({
        id: est.id,
        data: {
          scopeOfWork: description || undefined,
          taxRate,
          includeTax: taxRate > 0,
          includeLabor: laborItems.length > 0,
          includeMaterials: materialItems.length > 0,
        },
      });

      toast({ title: "Quote saved!", description: "Opening your project now." });
      setLocation(`/jobs/${finalJobId}`);
    } catch (err: unknown) {
      toast({
        title: "Save failed",
        description: err instanceof Error ? err.message : "Unknown error",
        variant: "destructive",
      });
    } finally {
      setIsSaving(false);
    }
  }

  const confidenceLabel = (c: string) =>
    c === "high" ? "High" : c === "estimate" ? "Estimate" : "Approximate";

  const stepIndex = STEPS.indexOf(step);

  // ── STEP: CLIENT ─────────────────────────────────────
  if (step === "client") {
    return (
      <div className="p-6 md:p-8 max-w-2xl mx-auto">
        <StepHeader step={step} />

        <div className="mt-8 space-y-6">
          <div>
            <h2 className="text-2xl font-bold text-foreground">Who is this quote for?</h2>
            <p className="text-muted-foreground mt-1">Enter the customer's name to get started.</p>
          </div>

          <div className="space-y-2">
            <Label className="text-base font-semibold">Customer Name</Label>
            <Input
              autoFocus
              placeholder="e.g. John Smith"
              value={clientNameInput}
              onChange={(e) => {
                setClientNameInput(e.target.value);
                setClientMode(null);
                setClientId(null);
              }}
              className="h-12 text-base"
              onKeyDown={(e) => {
                if (e.key === "Enter" && clientNameInput.trim()) {
                  if (exactMatch) {
                    proceedWithExistingClient(exactMatch.id);
                  } else {
                    proceedWithNewClient();
                  }
                }
              }}
            />
          </div>

          {/* Matching existing clients */}
          {matchingClients.length > 0 && !clientMode && (
            <div className="space-y-2">
              <p className="text-sm font-medium text-muted-foreground">Existing clients:</p>
              <div className="space-y-2">
                {matchingClients.map((c) => (
                  <button
                    key={c.id}
                    onClick={() => proceedWithExistingClient(c.id)}
                    className="w-full flex items-center justify-between p-3 rounded-xl border border-border bg-card hover:border-primary/50 hover:bg-primary/5 transition-all text-left"
                  >
                    <div className="flex items-center gap-3">
                      <div className="w-9 h-9 rounded-full bg-primary/10 flex items-center justify-center text-primary font-bold text-sm shrink-0">
                        {c.name.charAt(0).toUpperCase()}
                      </div>
                      <div>
                        <div className="font-medium text-foreground">{c.name}</div>
                        {c.email && <div className="text-xs text-muted-foreground">{c.email}</div>}
                      </div>
                    </div>
                    <div className="flex items-center gap-1 text-xs text-primary font-medium">
                      Add estimate <ChevronRight className="w-4 h-4" />
                    </div>
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* New client option */}
          {clientNameInput.trim() && !exactMatch && (
            <button
              onClick={proceedWithNewClient}
              className="w-full flex items-center justify-between p-3 rounded-xl border border-dashed border-primary/50 bg-primary/5 hover:bg-primary/10 transition-all text-left"
            >
              <div className="flex items-center gap-3">
                <div className="w-9 h-9 rounded-full bg-primary/20 flex items-center justify-center text-primary shrink-0">
                  <Plus className="w-5 h-5" />
                </div>
                <div>
                  <div className="font-medium text-foreground">Create new client</div>
                  <div className="text-sm text-muted-foreground">"{clientNameInput.trim()}"</div>
                </div>
              </div>
              <div className="flex items-center gap-1 text-xs text-primary font-medium">
                Continue <ChevronRight className="w-4 h-4" />
              </div>
            </button>
          )}

          {clientNameInput.trim() && (
            <Button
              className="w-full h-12 text-base"
              onClick={() => {
                if (exactMatch) {
                  proceedWithExistingClient(exactMatch.id);
                } else {
                  proceedWithNewClient();
                }
              }}
              disabled={!clientNameInput.trim()}
            >
              Continue <ArrowRight className="w-5 h-5 ml-2" />
            </Button>
          )}

          {/* Skip option */}
          <div className="text-center">
            <button
              onClick={() => setStep("describe")}
              className="text-sm text-muted-foreground hover:text-foreground transition-colors"
            >
              Skip — add client later
            </button>
          </div>
        </div>
      </div>
    );
  }

  // ── STEP: DESCRIBE ───────────────────────────────────
  if (step === "describe") {
    return (
      <div className="p-6 md:p-8 max-w-2xl mx-auto">
        <StepHeader step={step} onBack={() => setStep("client")} />

        <div className="mt-8 space-y-6">
          <div>
            <h2 className="text-2xl font-bold text-foreground">What's the job?</h2>
            <p className="text-muted-foreground mt-1">
              {clientMode === "existing" && selectedClient
                ? `Quoting for ${selectedClient.name}`
                : clientNameInput.trim()
                  ? `New client: ${clientNameInput.trim()}`
                  : "Describe the work to get an AI-generated quote."}
            </p>
          </div>

          {/* Job type */}
          <div className="space-y-1.5">
            <Label className="text-base font-semibold">Job Type</Label>
            <Select value={jobType} onValueChange={setJobType}>
              <SelectTrigger className="h-12">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {JOB_TYPES.map((t) => (
                  <SelectItem key={t} value={t}>{t}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {/* Job description */}
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <Label className="text-base font-semibold">Job Description</Label>
              <button
                onClick={() => setShowTemplate(!showTemplate)}
                className="text-xs text-primary hover:underline"
              >
                {showTemplate ? "Hide template" : "Show example"}
              </button>
            </div>

            {showTemplate && (
              <Card className="border-primary/20 bg-primary/5">
                <CardContent className="p-4">
                  <p className="text-sm text-foreground/80 whitespace-pre-line leading-relaxed">
                    {DESCRIPTION_TEMPLATE}
                  </p>
                  <Button
                    variant="outline"
                    size="sm"
                    className="mt-3"
                    onClick={() => {
                      const example = `Customer wants 120 feet of 6-inch seamless gutters installed on a single-story house. Existing gutters need to be removed. Include downspouts, hangers, end caps, corners, labor, disposal, and cleanup.`;
                      setDescription(example);
                      setShowTemplate(false);
                    }}
                  >
                    Use this example
                  </Button>
                </CardContent>
              </Card>
            )}

            <Textarea
              autoFocus
              placeholder={`Describe the job in detail...\n\nInclude: type of work, measurements, materials, location, condition of existing area, timeline, and anything special the customer asked for.`}
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              rows={6}
              className="resize-none text-base"
            />
            <p className="text-xs text-muted-foreground">
              The more detail you provide, the more accurate the AI estimate will be.
            </p>
          </div>

          <Button
            className="w-full h-12 text-base"
            onClick={handleGenerateAi}
            disabled={aiQuickQuote.isPending || !description.trim()}
          >
            {aiQuickQuote.isPending ? (
              <>
                <Loader2 className="w-5 h-5 mr-2 animate-spin" />
                AI is building your quote…
              </>
            ) : (
              <>
                <Sparkles className="w-5 h-5 mr-2" />
                Generate Quote with AI
              </>
            )}
          </Button>
        </div>
      </div>
    );
  }

  // ── STEP: PREVIEW ────────────────────────────────────
  if (step === "preview") {
    return (
      <div className="p-6 md:p-8 max-w-4xl mx-auto space-y-5 print:p-0">
        <StepHeader step={step} onBack={() => setStep("review")} />

        <div className="flex items-center gap-3 flex-wrap print:hidden mt-2">
          <div className="ml-auto flex gap-2">
            <Button variant="outline" size="sm" onClick={() => window.print()}>
              <Printer className="w-4 h-4 mr-1.5" /> Print / PDF
            </Button>
            <Button size="sm" onClick={handleSave} disabled={isSaving}>
              {isSaving ? (
                <Loader2 className="w-4 h-4 mr-1.5 animate-spin" />
              ) : (
                <Save className="w-4 h-4 mr-1.5" />
              )}
              Save Quote
            </Button>
          </div>
        </div>

        <Card className="print:shadow-none print:border-0">
          <CardContent className="p-6 sm:p-8 space-y-6">
            {/* Header */}
            <div className="flex flex-col sm:flex-row sm:justify-between gap-6 pb-6 border-b">
              <div>
                {company?.logoUrl && (
                  <img src={company.logoUrl} alt="logo" className="h-12 w-auto object-contain mb-3" />
                )}
                <h2 className="text-xl font-bold">{company?.name || "Your Company"}</h2>
                {company?.address && <div className="text-sm text-muted-foreground">{company.address}</div>}
                {company?.city && (
                  <div className="text-sm text-muted-foreground">
                    {company.city}{company.state ? `, ${company.state}` : ""} {company.zipCode || ""}
                  </div>
                )}
                {company?.phone && <div className="text-sm text-muted-foreground">{company.phone}</div>}
                {company?.email && <div className="text-sm text-muted-foreground">{company.email}</div>}
              </div>
              <div className="text-sm sm:text-right space-y-1">
                <div className="font-semibold text-base">ESTIMATE</div>
                <div className="text-muted-foreground">Date: {new Date().toLocaleDateString()}</div>
                {(selectedClient || clientNameInput.trim()) && (
                  <div className="mt-2">
                    <div className="font-medium">Bill To:</div>
                    <div>{selectedClient?.name || clientNameInput.trim()}</div>
                    {selectedClient?.address && (
                      <div className="text-muted-foreground">{selectedClient.address}</div>
                    )}
                    {selectedClient?.email && (
                      <div className="text-muted-foreground">{selectedClient.email}</div>
                    )}
                  </div>
                )}
                <div className="mt-2">
                  <div className="font-medium">Job Type:</div>
                  <div>{jobType}</div>
                </div>
              </div>
            </div>

            {description && (
              <div>
                <div className="text-xs font-semibold uppercase tracking-wider text-muted-foreground mb-1">
                  Scope of Work
                </div>
                <p className="text-sm text-foreground/90">{description}</p>
              </div>
            )}

            <PreviewSection title="Materials" items={materialItems} qtyLabel="Qty" rateLabel="Unit Price" />
            <PreviewSection title="Labor" items={laborItems} qtyLabel="Hrs" rateLabel="Rate/hr" />

            <div className="border-t pt-4">
              <div className="flex flex-col items-end gap-1.5 text-sm">
                <div className="flex gap-8 text-muted-foreground w-64 justify-between">
                  <span>Subtotal</span>
                  <span className="tabular-nums">{formatCurrency(subtotal)}</span>
                </div>
                {taxRate > 0 && (
                  <div className="flex gap-8 text-muted-foreground w-64 justify-between">
                    <span>Tax ({taxRate}%)</span>
                    <span className="tabular-nums">{formatCurrency(taxAmount)}</span>
                  </div>
                )}
                <div className="flex gap-8 font-bold text-lg pt-1.5 border-t w-64 justify-between">
                  <span>TOTAL</span>
                  <span className="tabular-nums">{formatCurrency(grandTotal)}</span>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        <div className="flex justify-end gap-3 print:hidden">
          <Button variant="outline" onClick={() => window.print()}>
            <Printer className="w-4 h-4 mr-1.5" /> Print / PDF
          </Button>
          <Button onClick={handleSave} disabled={isSaving} size="lg">
            {isSaving ? (
              <Loader2 className="w-4 h-4 mr-1.5 animate-spin" />
            ) : (
              <Save className="w-4 h-4 mr-1.5" />
            )}
            Save & Create Project
          </Button>
        </div>
      </div>
    );
  }

  // ── STEP: REVIEW (line item editor) ──────────────────
  return (
    <div className="p-6 md:p-8 max-w-4xl mx-auto space-y-5">
      <StepHeader step={step} onBack={() => setStep("describe")} />

      <div className="flex items-center justify-between mt-2">
        <div>
          <h2 className="text-xl font-bold text-foreground">Review Your Quote</h2>
          <p className="text-muted-foreground text-sm mt-0.5">
            {clientNameInput.trim() && `Client: ${selectedClient?.name || clientNameInput.trim()} · `}
            {jobType}
          </p>
        </div>
        {aiGenerated && (
          <Button
            variant="outline"
            size="sm"
            onClick={() => { setStep("describe"); setAiGenerated(false); }}
          >
            <Sparkles className="w-4 h-4 mr-1.5" /> Regenerate
          </Button>
        )}
      </div>

      {aiGenerated && (
        <Card className="border-amber-200 bg-amber-50">
          <CardContent className="p-3 flex items-start gap-2">
            <AlertTriangle className="w-4 h-4 text-amber-600 mt-0.5 shrink-0" />
            <p className="text-xs text-amber-800">
              AI estimates are approximate — review every line item and adjust prices before sending to your customer.
            </p>
          </CardContent>
        </Card>
      )}

      {/* Client & job info */}
      <div className="grid md:grid-cols-2 gap-4">
        <div className="space-y-1.5">
          <Label>Client</Label>
          <div className="flex items-center gap-2 p-3 rounded-lg border bg-card">
            <UserRound className="w-4 h-4 text-muted-foreground shrink-0" />
            <span className="text-sm font-medium">
              {selectedClient?.name || clientNameInput.trim() || "No client selected"}
            </span>
          </div>
        </div>
        <div className="space-y-1.5">
          <Label>Job Type</Label>
          <Select value={jobType} onValueChange={setJobType}>
            <SelectTrigger>
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              {JOB_TYPES.map((t) => (
                <SelectItem key={t} value={t}>{t}</SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      </div>

      <div className="space-y-1.5">
        <Label>Scope of Work / Description</Label>
        <Textarea
          placeholder="Briefly describe the work for the customer…"
          value={description}
          onChange={(e) => setDescription(e.target.value)}
          rows={3}
          className="resize-none"
        />
      </div>

      {/* Line items */}
      <div className="space-y-2">
        <div className="flex items-center justify-between">
          <Label className="text-base font-semibold">Line Items</Label>
          <div className="flex gap-2">
            <Button variant="outline" size="sm" onClick={() => setItems((p) => [...p, emptyItem("material")])}>
              <Plus className="w-3.5 h-3.5 mr-1" /> Material
            </Button>
            <Button variant="outline" size="sm" onClick={() => setItems((p) => [...p, emptyItem("labor")])}>
              <Plus className="w-3.5 h-3.5 mr-1" /> Labor
            </Button>
          </div>
        </div>

        <Card>
          <CardContent className="p-0">
            {items.length === 0 ? (
              <div className="py-10 text-center text-sm text-muted-foreground">
                No line items yet. Add a material or labor row above.
              </div>
            ) : (
              <div className="divide-y">
                {items.map((item) => {
                  const hint = hints[item.id];
                  return (
                    <div key={item.id} className="p-3 space-y-2">
                      <div className="flex items-start gap-2">
                        <Badge
                          variant={item.section === "labor" ? "secondary" : "outline"}
                          className="mt-1.5 shrink-0"
                        >
                          {item.section === "labor" ? "Labor" : "Material"}
                        </Badge>
                        <div className="flex-1 grid grid-cols-12 gap-2">
                          <Input
                            className="col-span-12 sm:col-span-5"
                            placeholder={item.section === "labor" ? "Task description" : "Item name"}
                            value={item.description}
                            onChange={(e) => updateItem(item.id, { description: e.target.value })}
                          />
                          <Input
                            className="col-span-3 sm:col-span-2"
                            type="number"
                            placeholder={item.section === "labor" ? "Hrs" : "Qty"}
                            value={item.qty}
                            onChange={(e) => updateItem(item.id, { qty: parseFloat(e.target.value) || 0 })}
                          />
                          <Input
                            className="col-span-3 sm:col-span-2"
                            placeholder="Unit"
                            value={item.unit}
                            disabled={item.section === "labor"}
                            onChange={(e) => updateItem(item.id, { unit: e.target.value })}
                          />
                          <Input
                            className="col-span-4 sm:col-span-2"
                            type="number"
                            placeholder={item.section === "labor" ? "Rate/hr" : "Unit price"}
                            value={item.unitPrice}
                            onChange={(e) => updateItem(item.id, { unitPrice: parseFloat(e.target.value) || 0 })}
                          />
                          <div className="col-span-2 sm:col-span-1 flex items-center justify-end text-sm font-medium tabular-nums">
                            {formatCurrency(item.qty * item.unitPrice)}
                          </div>
                        </div>
                        <button
                          onClick={() => removeItem(item.id)}
                          className="mt-1.5 text-muted-foreground hover:text-destructive transition-colors shrink-0"
                          title="Remove"
                        >
                          <X className="w-4 h-4" />
                        </button>
                      </div>

                      {item.section === "material" && (
                        <div className="flex flex-wrap items-center gap-2 pl-1">
                          <button
                            onClick={() => handleCheckPrice(item)}
                            disabled={hintLoading[item.id]}
                            className="flex items-center gap-1 text-xs text-primary hover:underline disabled:opacity-50"
                          >
                            {hintLoading[item.id] ? (
                              <Loader2 className="w-3 h-3 animate-spin" />
                            ) : (
                              <Tag className="w-3 h-3" />
                            )}
                            Check price
                          </button>
                          {hint && (
                            <>
                              {hint.historical.latest != null && (
                                <button
                                  onClick={() => updateItem(item.id, { unitPrice: hint.historical.latest! })}
                                  className="flex items-center gap-1.5 rounded-md border px-2 py-1 text-xs hover:bg-muted"
                                >
                                  <Badge variant="secondary" className="text-[10px]">Your records</Badge>
                                  <span className="font-medium">{formatCurrency(hint.historical.latest)}</span>
                                  <span className="text-primary">· Use</span>
                                </button>
                              )}
                              {hint.retailEstimates
                                .filter((e) => e.price != null)
                                .map((e, i) => (
                                  <button
                                    key={i}
                                    onClick={() => updateItem(item.id, { unitPrice: e.price! })}
                                    className="flex items-center gap-1.5 rounded-md border px-2 py-1 text-xs hover:bg-muted"
                                  >
                                    <Badge variant="outline" className="text-[10px]">AI estimate</Badge>
                                    <span className="font-medium">{formatCurrency(e.price!)}</span>
                                    <span className="text-muted-foreground">{e.store}</span>
                                    <span className="text-muted-foreground">· {confidenceLabel(e.confidence)}</span>
                                    <span className="text-primary">· Use</span>
                                  </button>
                                ))}
                              {hint.historical.latest == null &&
                                hint.retailEstimates.filter((e) => e.price != null).length === 0 && (
                                  <span className="text-xs text-muted-foreground">No pricing found.</span>
                                )}
                            </>
                          )}
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Totals */}
      <div className="flex flex-col items-end gap-1.5 text-sm">
        <div className="flex gap-8 text-muted-foreground w-64 justify-between">
          <span>Subtotal</span>
          <span className="tabular-nums">{formatCurrency(subtotal)}</span>
        </div>
        <div className="flex items-center gap-2 w-64 justify-between text-muted-foreground">
          <div className="flex items-center gap-1.5">
            <span>Tax</span>
            <Input
              type="number"
              min={0}
              max={100}
              step={0.1}
              value={taxRate}
              onChange={(e) => setTaxRate(parseFloat(e.target.value) || 0)}
              className="w-16 h-7 text-xs px-1.5"
            />
            <span className="text-xs">%</span>
          </div>
          <span className="tabular-nums">{formatCurrency(taxAmount)}</span>
        </div>
        <div className="flex gap-8 font-bold text-lg pt-1.5 border-t w-64 justify-between">
          <span>TOTAL</span>
          <span className="tabular-nums">{formatCurrency(grandTotal)}</span>
        </div>
      </div>

      <div className="flex justify-end">
        <Button
          onClick={() => setStep("preview")}
          disabled={items.length === 0}
          size="lg"
        >
          Preview Quote <ArrowRight className="w-4 h-4 ml-1.5" />
        </Button>
      </div>
    </div>
  );
}

function StepHeader({ step, onBack }: { step: Step; onBack?: () => void }) {
  const stepIndex = STEPS.indexOf(step);

  return (
    <div className="space-y-4">
      {onBack && (
        <button
          onClick={onBack}
          className="flex items-center gap-1.5 text-sm text-muted-foreground hover:text-foreground transition-colors"
        >
          <ArrowLeft className="w-4 h-4" /> Back
        </button>
      )}
      {/* Progress bar */}
      <div className="flex items-center gap-2">
        {STEPS.map((s, i) => {
          const done = i < stepIndex;
          const active = i === stepIndex;
          return (
            <div key={s} className="flex items-center gap-2 flex-1 min-w-0">
              <div className="flex items-center gap-1.5 shrink-0">
                <div
                  className={`w-6 h-6 rounded-full flex items-center justify-center text-xs font-medium transition-all ${
                    active
                      ? "bg-primary text-primary-foreground"
                      : done
                        ? "bg-primary/20 text-primary"
                        : "bg-muted text-muted-foreground"
                  }`}
                >
                  {done ? <Check className="w-3.5 h-3.5" /> : i + 1}
                </div>
                <span className={`text-xs font-medium hidden sm:inline ${
                  active ? "text-foreground" : done ? "text-primary" : "text-muted-foreground"
                }`}>
                  {STEP_LABELS[s]}
                </span>
              </div>
              {i < STEPS.length - 1 && (
                <div className={`flex-1 h-px ${done ? "bg-primary/30" : "bg-border"}`} />
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
}

function PreviewSection({
  title,
  items,
  qtyLabel,
  rateLabel,
}: {
  title: string;
  items: LineItem[];
  qtyLabel: string;
  rateLabel: string;
}) {
  if (items.length === 0) return null;
  const subtotal = items.reduce((s, i) => s + i.qty * i.unitPrice, 0);
  return (
    <div>
      <div className="flex items-center gap-2 mb-2">
        <h3 className="text-sm font-semibold uppercase tracking-wider text-muted-foreground">{title}</h3>
        <div className="flex-1 h-px bg-border" />
      </div>
      <table className="w-full text-sm">
        <thead>
          <tr className="text-muted-foreground text-xs">
            <th className="text-left pb-1.5">Description</th>
            <th className="text-right pb-1.5 w-16">{qtyLabel}</th>
            <th className="text-right pb-1.5 w-24">{rateLabel}</th>
            <th className="text-right pb-1.5 w-24">Amount</th>
          </tr>
        </thead>
        <tbody className="divide-y">
          {items.map((item) => (
            <tr key={item.id}>
              <td className="py-1.5 pr-2">{item.description || "—"}</td>
              <td className="py-1.5 text-right tabular-nums">
                {item.qty}
                {item.section === "material" && item.unit ? ` ${item.unit}` : ""}
              </td>
              <td className="py-1.5 text-right tabular-nums">{formatCurrency(item.unitPrice)}</td>
              <td className="py-1.5 text-right font-medium tabular-nums">
                {formatCurrency(item.qty * item.unitPrice)}
              </td>
            </tr>
          ))}
        </tbody>
      </table>
      <div className="flex justify-end mt-1">
        <span className="text-sm text-muted-foreground">
          {title} subtotal: <span className="font-medium text-foreground">{formatCurrency(subtotal)}</span>
        </span>
      </div>
    </div>
  );
}
